"use client"
import { CompatibiltyProfile, RamSlots } from '@prisma/client'
import React, { useEffect, useState, useCallback } from 'react'
import { Filter, ProfileType } from '../page'
import { Motherboard } from './Motherboard'
import { Processor } from './Processor'
import { Product } from '@/types'
import { AllProductsCompatibility, defaultAllProductsCompatibility } from './comps'
import { Memory, Ram } from './Ram'
import { HardDisk } from './HardDisk'
import { Power } from './Power'
import { Case } from './Case'
import { Cooling } from './Cooling'
import Details from './details'
import { GraphicCard } from './GraphicCard'
import { Screen } from './Screen'
import axios from 'axios'
import { useLanguage } from "@/context/language-context";
import { UI_TEXT } from "@/i18n/ui-text";
export function extractNumber(text: string): number | null {
  const regex = /^(\d+)/
  const match = text.match(regex)
  if (match) return parseInt(match[1], 10)
  return null
}

export interface SelectedFeatures {
  [key: string]: number | undefined
}

const EXPIRATION_TIME = 12 * 60 * 60 * 1000

const saveToLocalStorage = (key: string, value: any) => {
  if (value != retrieveFromLocalStorage(key)) {
    const data = { value, timestamp: new Date().getTime() }
    localStorage.setItem(key, JSON.stringify(data))
  }
}

export function extractGpuSize(title: string): number | null {
  const regex = /(\d+)\s*(g|gb|go)\b/i
  const match = title.match(regex)
  if (match) return parseInt(match[1], 10)
  return null
}

export function extractCoreCount(text: string): number | null {
  const regex = /(\d+)\s*(CŒURS|COEURS|Cores)\b/i
  const match = text.match(regex)
  if (match) return parseInt(match[1], 10)
  return null
}

export function extractPerformanceCoreClock(text: string): number | null {
  const normalizedText = text.replace(/(\d+),(\d+)/g, '$1.$2')
  const regex = /(\d+\.?\d*)\s*GHz\b/gi
  const matches = normalizedText.match(regex)
  if (matches) {
    const clocks = matches
      .map((m) => parseFloat(m.replace(/GHz/i, '').trim()))
      .filter((n) => !isNaN(n))
    return clocks.length > 0 ? Math.max(...clocks) : null
  }
  return null
}

const retrieveFromLocalStorage = (key: string) => {
  if (typeof localStorage !== 'undefined' && localStorage.getItem(key)) {
    const data = localStorage.getItem(key)
    if (data) {
      const parsedData = JSON.parse(data)
      const { value, timestamp } = parsedData
      const currentTime = new Date().getTime()
      if (currentTime - timestamp < EXPIRATION_TIME) {
        if (key == "ramId" && (value.length == 1 || value.length == 3)) {
          return [...value, null]
        }
        return value
      } else {
        localStorage.removeItem(key)
      }
    } else if (key === "ramId") {
      return [null, null, null, null]
    }
  } if (key == "ramId") {
    return [null, null, null, null]
  }
  return null
}

export const BuildForm = (props: {
  profiles: ProfileType[],
  mark: Filter
  pouce: Filter
  refreshRate: Filter
  resolution: Filter

  gpuBrand: Filter
  gpuArchBrand: Filter
  graphiccardName: Filter

  coolingcPUSupport: Filter
  fansNumber: Filter
  coolingType: Filter
  coolingMark: Filter

  psCertification: Filter
  powersupplyMarque: Filter

  pCcaseRGBType: Filter
  pCcaseNumberofFansPreinstalled: Filter
  pCcaseCaseformat: Filter
  pCcaseBrand: Filter

  harddiskType: Filter
  harddiskComputerinterface: Filter
  harddiskCapacity: Filter
  harddiskBrand: Filter
  processorModel: Filter
  cPUSupport: Filter
  motherboardchipset: Filter
  motherboardcpusupport: Filter
  motherboardformat: Filter
  motherboardramslots: Filter
  motherboardmanufacturer: Filter
  memoryFrequency: Filter
  memoryMarque: Filter
  memoryNumber: Filter
  memoryType: Filter
}) => {
  
  const { lang } = useLanguage();
  const ui = UI_TEXT[lang];
  const [motherboardId, setMotherboardId] = useState<Product | undefined>(retrieveFromLocalStorage('motherboardId'))
  const [allProductCompatibility, setAllProductCompatibility] = useState<AllProductsCompatibility>(defaultAllProductsCompatibility)
  const [processorId, setProcessorId] = useState<Product | undefined>(retrieveFromLocalStorage('processorId'))
  const [gpuId, setGpuId] = useState<Product | undefined>(retrieveFromLocalStorage('gpuId'))
  const [ramId, setRamId] = useState<(Memory | null)[]>(retrieveFromLocalStorage('ramId') || [null, null])
  const [hardDiskSecondaire, setHardDiskSecondaire] = useState<Product | undefined>(retrieveFromLocalStorage('hardDiskSecondaire'))
  const [hardDiskPrimaireId, sethardDiskPrimaireId] = useState<Product | undefined>(retrieveFromLocalStorage('hardDiskPrimaireId'))
  const [caseId, setCase] = useState<Product | undefined>(retrieveFromLocalStorage('caseId'))
  const [powerId, setPowerId] = useState<Product | undefined>(retrieveFromLocalStorage('powerId'))
  const [cooling, setcooling] = useState<Product | undefined>(retrieveFromLocalStorage('cooling'))
  const [screen, setscreen] = useState<Product | undefined>(retrieveFromLocalStorage('screen'))
  const [prix, setPrix] = useState<number>(0)
  const [ramSlotNumber, setRamSlotNumber] = useState(2)
  const [ramSlotType, setRamSlotType] = useState("")
  const [selectedFeatures, setSelectedFeatures] = useState<SelectedFeatures>({})

  // ✅ FIX: stabilize callbacks to avoid re-running child effects and parent state updates
  const addFeature = useCallback((featureName: string, value: any) => {
    setSelectedFeatures((prev) => ({
      ...prev,
      [featureName]: value,
    }))
  }, [])

  const removeFeature = useCallback((featureName: string) => {
    setSelectedFeatures((prev) => {
      const newFeatures = { ...prev }
      delete newFeatures[featureName]
      return newFeatures
    })
  }, [])

  const Number = async () => {
    try {
      const response = await axios.get(`/api/motherboard/RamSlots?id=${motherboardId?.id}`)
      const dataa: RamSlots = response.data
      setRamSlotNumber(dataa.number)
      setRamSlotType(dataa.type)
    } catch (error) {
      console.error('Error fetching data:', error)
    }
  }

  function haveCommonElement<T>(set1: T[], array2: T[]): boolean {
    const array1 = Array.from(set1)
    for (const item of array1) {
      if (array2.includes(item)) return true
    }
    return false
  }

  // ✅ FIX: stable function + functional setState (prevents render loops when children call it)
  const setCompatibility = useCallback((updates: Record<string, { message: string; error: boolean }>) => {
    setAllProductCompatibility((prev) => ({
      Compatibility: {
        ...prev.Compatibility,
        ...updates,
      },
    }))
  }, [])

  useEffect(() => {
    const updates: Record<string, { message: string; error: boolean }> = {}

    if (motherboardId) {
      Number()
      const MProfiles = props.profiles.filter((e) => e.motherboards.find((ee) => ee.productId == motherboardId.id))
      if (processorId) {
        const PProfiles = props.profiles.filter((e) => e.CPUs.find((ee) => ee.productId == processorId.id))
        if (haveCommonElement(MProfiles, PProfiles)) {
          if (cooling) {
            const CProfiles = props.profiles.filter((e) => e.coolings.find((ee) => ee.productId == cooling.id))
            if (haveCommonElement(CProfiles, PProfiles)) {
              updates['processorCompatibility'] = { message: 'Compatible', error: false }
            } else {
              updates['processorCompatibility'] = { message: 'CPU Cooler Not Compatible', error: true }
            }
          } else {
            updates['processorCompatibility'] = { message: 'Compatible', error: false }
          }
          updates['motherboardCompatibility'] = { message: 'Compatible', error: false }
        } else {
          updates['motherboardCompatibility'] = { message: 'Not Compatible', error: true }
          updates['processorCompatibility'] = { message: 'Not Compatible', error: true }
        }
      }
    } else {
      setRamSlotType("")
      updates['motherboardCompatibility'] = { message: 'Please select a motherboard', error: true }
      if (processorId) {
        updates['processorCompatibility'] = { message: 'Please select a motherboard', error: true }
      }
    }

    if (processorId) {
      const PProfiles = props.profiles.filter((e) => e.CPUs.find((ee) => ee.productId == processorId.id))
      if (motherboardId) {
        const MProfiles = props.profiles.filter((e) => e.motherboards.find((ee) => ee.productId == motherboardId.id))
        if (haveCommonElement(MProfiles, PProfiles)) {
          if (cooling) {
            const CProfiles = props.profiles.filter((e) => e.coolings.find((ee) => ee.productId == cooling.id))
            if (haveCommonElement(CProfiles, PProfiles)) {
              updates['processorCompatibility'] = { message: 'Compatible', error: false }
            } else {
              updates['processorCompatibility'] = { message: 'CPU Cooler Not Compatible', error: true }
            }
          } else {
            updates['processorCompatibility'] = { message: 'Compatible', error: false }
          }
          updates['motherboardCompatibility'] = { message: 'Compatible', error: false }
        } else {
          updates['motherboardCompatibility'] = { message: 'Not Compatible', error: true }
          updates['processorCompatibility'] = { message: 'Not Compatible', error: true }
        }
      }

      const corsPerformance = extractPerformanceCoreClock(processorId.description)
      addFeature("CPU_Performance_Core_Clock", corsPerformance)
      const corCount = extractCoreCount(processorId.description)
      addFeature("CPU_Core_Count", corCount)
    } else {
      if (motherboardId) {
        updates['motherboardCompatibility'] = { message: 'Please select a processor', error: true }
      }
      updates['processorCompatibility'] = { message: 'Please select a processor', error: true }
    }

    if (gpuId) {
      if (motherboardId) {
        updates['gpuCompatibility'] = { message: 'Compatible', error: false }
      } else {
        updates['gpuCompatibility'] = { message: 'Please select a motherboard', error: true }
      }
      const gpuSize = extractGpuSize(gpuId.name)
      addFeature("Video Card_Memory", gpuSize)
    } else {
      updates['gpuCompatibility'] = { message: 'Please check if a graphics card is already integrated.', error: false }
    }

    const data: string[] = []
    if (motherboardId) {
      ramId.map((e, k) => {
        if (e != null) {
          let message = "Please select at least one RAM module"
          const MProfiles = props.profiles.filter((e) => e.motherboards.find((ee) => ee.productId == motherboardId.id))
          if (e.memories[0].type.name === ramSlotType) {
            const RProfiles = props.profiles.filter((xe) => xe.RAMs.find((ee) => ee.Components.find((re) => re.productId === e.id)))
            if (haveCommonElement(MProfiles, RProfiles)) {
              message = 'Compatible'
            } else {
              message = 'Not Compatible'
            }
          } else {
            if (ramSlotType == "") {
              message = 'Loading...'
            } else {
              message = ramSlotType + ' at ' + (k + 1) + 'is required'
            }
          }
          data.push(message)
        }
      })
    }

    if (data.length > 0) {
      const newdata = data.filter((e) => e != 'Compatible')
      if (newdata.length == 0) {
        updates['ramCompatibility'] = { message: 'Compatible', error: false }
      } else {
        if (newdata[0] == 'Loading...') {
          updates['ramCompatibility'] = { message: 'Loading...', error: true }
        } else {
          updates['ramCompatibility'] = { message: newdata.join(", "), error: true }
        }
      }
    } else {
      if (motherboardId) {
        updates['ramCompatibility'] = { message: 'Please select at least one RAM module', error: true }
      } else {
        updates['ramCompatibility'] = { message: 'Please select a motherboard', error: true }
      }
    }

    if (hardDiskPrimaireId) {
      const PProfiles = props.profiles.filter((e) => e.disks.find((ee) => ee.Components.find((Xc) => Xc.productId == hardDiskPrimaireId.id)))
      if (motherboardId) {
        const MProfiles = props.profiles.filter((e) => e.motherboards.find((ee) => ee.productId == motherboardId.id))
        if (haveCommonElement(MProfiles, PProfiles)) {
          if (hardDiskSecondaire) {
            const PProfiless = props.profiles.filter((e) => e.disks.find((ee) => ee.Components.find((Xc) => Xc.productId == hardDiskSecondaire.id)))
            if (haveCommonElement(MProfiles, PProfiless)) {
              updates['hardDiskCompatibility'] = { message: 'Compatible', error: false }
            } else {
              updates['hardDiskCompatibility'] = { message: 'Secondary Storage Not Compatible', error: true }
            }
          } else {
            updates['hardDiskCompatibility'] = { message: 'Compatible', error: false }
          }
        } else {
          updates['hardDiskCompatibility'] = { message: 'Not Compatible', error: true }
        }
      } else {
        updates['hardDiskCompatibility'] = { message: 'Please select a motherboard', error: true }
      }
    } else {
      updates['hardDiskCompatibility'] = { message: 'Please select a hard drive', error: true }
    }

    if (powerId) {
      const PProfiles = props.profiles.filter((e) => e.powersupplys.find((ee) => ee.productId == powerId.id))
      if (motherboardId) {
        const MProfiles = props.profiles.filter((e) => e.motherboards.find((ee) => ee.productId == motherboardId.id))
        if (haveCommonElement(MProfiles, PProfiles)) {
          updates['powerCompatibility'] = { message: 'Compatible', error: false }
        } else {
          updates['powerCompatibility'] = { message: 'Not Compatible', error: true }
        }
      } else {
        updates['powerCompatibility'] = { message: 'Please select a motherboard', error: true }
      }
    } else {
      updates['powerCompatibility'] = { message: 'Please select the power supply', error: true }
    }

    if (caseId) {
      const PProfiles = props.profiles.filter((e) => e.cases.find((ee) => ee.productId == caseId.id))
      if (motherboardId) {
        const MProfiles = props.profiles.filter((e) => e.motherboards.find((ee) => ee.productId == motherboardId.id))
        if (haveCommonElement(MProfiles, PProfiles)) {
          updates['caseCompatibility'] = { message: 'Compatible', error: false }
        } else {
          updates['caseCompatibility'] = { message: 'Not Compatible', error: true }
        }
      } else {
        updates['caseCompatibility'] = { message: 'Please select a motherboard', error: true }
      }
    } else {
      updates['caseCompatibility'] = { message: 'Please select a case', error: true }
    }

    setCompatibility(updates)
    // console.log(selectedFeatures)
    // console.log(allProductCompatibility)
  }, [motherboardId, processorId, gpuId, ramId, hardDiskPrimaireId, hardDiskSecondaire, caseId, powerId, cooling, screen, ramSlotType, props.profiles, setCompatibility, addFeature])

  useEffect(() => {
    const updates: Record<string, { message: string; error: boolean }> = {}
    const data: string[] = []
    if (motherboardId) {
      ramId.map((e, k) => {
        if (e != null) {
          let message = "Please select at least one RAM module."
          const MProfiles = props.profiles.filter((e) => e.motherboards.find((ee) => ee.productId == motherboardId.id))
          if (e.memories[0].type.name === ramSlotType) {
            const RProfiles = props.profiles.filter((xe) => xe.RAMs.find((ee) => ee.Components.find((re) => re.productId === e.id)))
            if (haveCommonElement(MProfiles, RProfiles)) {
              message = 'Compatible'
            } else {
              message = (k + 1) + ' not Compatible'
            }
          } else {
            message = ramSlotType + ' at ' + (k + 1) + ' is required'
          }
          data.push(message)
        }
      })
    }

    if (data.length > 0) {
      const newdata = data.filter((e) => e != 'Compatible')
      if (newdata.length == 0) {
        updates['ramCompatibility'] = { message: 'Compatible', error: false }
      } else {
        updates['ramCompatibility'] = { message: newdata.join(", "), error: true }
      }
    } else {
      if (motherboardId) {
        updates['ramCompatibility'] = { message: 'Please select at least one RAM module', error: true }
      } else {
        updates['ramCompatibility'] = { message: 'Please select a motherboard', error: true }
      }
    }

    setCompatibility(updates)
  }, [ramSlotType, motherboardId, ramId, props.profiles, setCompatibility])

  useEffect(() => {
    saveToLocalStorage('motherboardId', motherboardId)
    saveToLocalStorage('processorId', processorId)
    saveToLocalStorage('gpuId', gpuId)
    saveToLocalStorage('ramId', ramId)
    saveToLocalStorage('hardDiskPrimaireId', hardDiskPrimaireId)
    saveToLocalStorage('hardDiskSecondaire', hardDiskSecondaire)
    saveToLocalStorage('caseId', caseId)
    saveToLocalStorage('powerId', powerId)
    saveToLocalStorage('cooling', cooling)
    saveToLocalStorage('screen', screen)
    calculePrix()
  }, [motherboardId, processorId, gpuId, ramId, hardDiskPrimaireId, hardDiskSecondaire, caseId, powerId, cooling, screen])

  const calculePrix = () => {
    let prix1 = 0
    if (motherboardId) prix1 += parseInt(motherboardId.price.toString())
    if (processorId) prix1 += parseInt(processorId.price.toString())
    if (gpuId) prix1 += parseInt(gpuId.price.toString())
    ramId.map((e) => { if (e != null) prix1 += parseInt(e.price.toString()) })
    if (hardDiskPrimaireId) prix1 += parseInt(hardDiskPrimaireId.price.toString())
    if (hardDiskSecondaire) prix1 += parseInt(hardDiskSecondaire.price.toString())
    if (caseId) prix1 += parseInt(caseId.price.toString())
    if (powerId) prix1 += parseInt(powerId.price.toString())
    if (cooling) prix1 += parseInt(cooling.price.toString())
    if (screen) prix1 += parseInt(screen.price.toString())
    setPrix(prix1)
  }

  const viderTous = () => {
    setMotherboardId(undefined)
    setPowerId(undefined)
    setProcessorId(undefined)
    setPowerId(undefined)
    sethardDiskPrimaireId(undefined)
    setHardDiskSecondaire(undefined)
    setCase(undefined)
    setGpuId(undefined)
    setcooling(undefined)
    setscreen(undefined)
    setRamId([null, null])
  }

  return (
    <div className="relative z-0 space-y-8">
      <div>
        <h1 className="text-4xl font-bold text-foreground mb-2">{ui.navBuildYourPc}</h1>
        <div className="h-1 w-20 bg-gradient-to-r from-[#38BDF8] to-[#0EA5E9] rounded-full"></div>
      </div>

      <Motherboard
        cpuId={processorId}
        selectedCompatibility={allProductCompatibility}
        motherboardId={motherboardId}
        setMotherboardId={setMotherboardId}
        profiles={props.profiles}
        motherboardchipset={props.motherboardchipset}
        motherboardcpusupport={props.motherboardcpusupport}
        motherboardformat={props.motherboardformat}
        motherboardramslots={props.motherboardramslots}
        motherboardmanufacturer={props.motherboardmanufacturer}
      />
      <Processor
        selectedFeatures={selectedFeatures}
        removeFeature={removeFeature}
        addFeature={addFeature}
        setProcessorId={setProcessorId}
        processorId={processorId}
        motherboardId={motherboardId}
        selectedCompatibility={allProductCompatibility}
        profiles={props.profiles}
        cPUSupport={props.cPUSupport}
        processorModel={props.processorModel}
      />
      <GraphicCard
        selectedFeatures={selectedFeatures}
        removeFeature={removeFeature}
        addFeature={addFeature}
        setProcessorId={setGpuId}
        processorId={gpuId}
        motherboardId={motherboardId}
        selectedCompatibility={allProductCompatibility}
        profiles={props.profiles}
        gpuArchBrand={props.gpuArchBrand}
        gpuBrand={props.gpuBrand}
        graphiccardName={props.graphiccardName}
      />
      <Ram
        selectedFeatures={selectedFeatures}
        removeFeature={removeFeature}
        addFeature={addFeature}
        ramSlotNumber={ramSlotNumber}
        ramSlotType={ramSlotType}
        rams={ramId}
        setRams={setRamId}
        selectedCompatibility={allProductCompatibility}
        motherboardId={motherboardId}
        setMotherboardId={setMotherboardId}
        profiles={props.profiles}
        memoryFrequency={props.memoryFrequency}
        memoryMarque={props.memoryMarque}
        memoryNumber={props.memoryNumber}
        memoryType={props.memoryType}
        setCompatibility={setCompatibility}
      />
      <HardDisk
        role={<>
          {ui.builderCompatprimary} <p className='text-xs text-[#00e0ff] p-1'>{ui.builderRequiredTag}</p>
        </>}
        setProcessorId={sethardDiskPrimaireId}
        processorId={hardDiskPrimaireId}
        motherboardId={motherboardId}
        selectedCompatibility={allProductCompatibility}
        profiles={props.profiles}
        harddiskBrand={props.harddiskBrand}
        harddiskCapacity={props.harddiskCapacity}
        harddiskComputerinterface={props.harddiskComputerinterface}
        harddiskType={props.harddiskType}
      />
      <HardDisk
        role={<>{ui.builderCompatsecondary}</>}
        setProcessorId={setHardDiskSecondaire}
        processorId={hardDiskSecondaire}
        motherboardId={motherboardId}
        selectedCompatibility={allProductCompatibility}
        profiles={props.profiles}
        harddiskBrand={props.harddiskBrand}
        harddiskCapacity={props.harddiskCapacity}
        harddiskComputerinterface={props.harddiskComputerinterface}
        harddiskType={props.harddiskType}
      />
      <Power
        selectedFeatures={selectedFeatures}
        removeFeature={removeFeature}
        addFeature={addFeature}
        setProcessorId={setPowerId}
        processorId={powerId}
        motherboardId={motherboardId}
        selectedCompatibility={allProductCompatibility}
        profiles={props.profiles}
        powersupplyMarque={props.powersupplyMarque}
        psCertification={props.psCertification}
      />
      <Case
        setProcessorId={setCase}
        processorId={caseId}
        motherboardId={motherboardId}
        selectedCompatibility={allProductCompatibility}
        profiles={props.profiles}
        pCcaseBrand={props.pCcaseBrand}
        pCcaseCaseformat={props.pCcaseCaseformat}
        pCcaseNumberofFansPreinstalled={props.pCcaseNumberofFansPreinstalled}
        pCcaseRGBType={props.pCcaseRGBType}
      />
      <Cooling
        setProcessorId={setcooling}
        processorId={cooling}
        motherboardId={motherboardId}
        selectedCompatibility={allProductCompatibility}
        profiles={props.profiles}
        coolingMark={props.coolingMark}
        coolingType={props.coolingType}
        coolingcPUSupport={props.coolingcPUSupport}
        fansNumber={props.fansNumber}
      />
      <Screen
        setProcessorId={setscreen}
        processorId={screen}
        motherboardId={motherboardId}
        selectedCompatibility={allProductCompatibility}
        profiles={props.profiles}
        mark={props.mark}
        pouce={props.pouce}
        refreshRate={props.refreshRate}
        resolution={props.resolution}
      />
      <Details
        motherboardId={motherboardId}
        processorId={processorId}
        ramId={ramId}
        gpuId={gpuId}
        hardDiskPrimaireId={hardDiskPrimaireId}
        hardDiskSecondaire={hardDiskSecondaire}
        caseId={caseId}
        powerId={powerId}
        cooling={cooling}
        screen={screen}
        prix={prix}
        allProductCompatibility={allProductCompatibility}
        vider={viderTous}
      />
    </div>
  )
}
